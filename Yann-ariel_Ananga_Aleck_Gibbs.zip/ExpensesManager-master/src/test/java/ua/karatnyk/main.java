package ua.karatnyk;
import java.text.ParseException;

import ua.karatnyk.TestCurrencyConvertor;
public class main {
    public static void main(String[] args) throws ParseException {
		TestCurrencyConvertor t =new TestCurrencyConvertor();
		t.currency20();
	}
}
