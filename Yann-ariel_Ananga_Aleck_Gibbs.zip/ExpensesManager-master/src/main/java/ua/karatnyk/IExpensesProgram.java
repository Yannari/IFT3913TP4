package ua.karatnyk;

public interface IExpensesProgram {
	
	void start();
	
}
