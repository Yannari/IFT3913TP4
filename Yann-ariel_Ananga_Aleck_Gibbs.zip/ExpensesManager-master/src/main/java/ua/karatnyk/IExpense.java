package ua.karatnyk;

public interface IExpense {
	
	double getAmount();
	
	String getCurrency();
	
	String getNameProduct();
	
	String toString();

}
