package ua.karatnyk;

import ua.karatnyk.impl.ExpensesProgram;

public class App 
{
    public static void main( String[] args )
    {
        ExpensesProgram program = new ExpensesProgram();
        program.start();
        
        
    }
}
