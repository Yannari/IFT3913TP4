# IFT3913TP4
Exécuter La classe testCurrencyConvertor dans ce dossier : -master\src\test\java\ua\karatnyk